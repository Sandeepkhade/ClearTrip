//
//  PlayerViewController.swift
//  MediaPlayer
//
//  Created by Devarshi on 28/10/23.
//

import UIKit
import AVFoundation

class PlayerViewController: UIViewController {

    var song : MySongs?
    @IBOutlet weak var mAlbumLbl: UILabel!
    @IBOutlet weak var mArtistLbl: UILabel!
    @IBOutlet weak var mTitleLbl: UILabel!
    
    var audioPlayer: AVAudioPlayer?
      var avPlayer:AVPlayer?
      var playerItem:AVPlayerItem?
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        print("Song to Play : \(song?.url ?? "")")

        let url = URL(string: "https://www.learningcontainer.com/wp-content/uploads/2020/02/Kalimba.mp3")
        let playerItem:AVPlayerItem = AVPlayerItem(url: url!)
        avPlayer = AVPlayer(playerItem: playerItem)
        let playerLayer=AVPlayerLayer(player: avPlayer!)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        createPlayerUI()
    }
    
    func createPlayerUI() {
         
        self.mAlbumLbl.text = song?.album
        self.mArtistLbl.text = song?.artist
        self.mTitleLbl.text = song?.title
    }
    
    func playMusic(url: URL?) {
 
    }
    //Music Control
    @IBAction func playMusicBtn(_ sender: Any) {
        avPlayer!.play()
    }
    @IBAction func pauseMusicBtn(_ sender: Any) {
        print("Pause Music")
        avPlayer!.pause()
    }
    @IBAction func stopMusicBtn(_ sender: Any) {
        print("Stop Music")
        audioPlayer?.stop()

    }
    
}
