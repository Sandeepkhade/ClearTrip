//
//  PlayerViewController.swift
//  MediaPlayer
//
//  Created by Devarshi on 28/10/23.
//

import UIKit
import AVFoundation

class PlayerViewController: UIViewController {

    var song : MySongs?
    @IBOutlet weak var mAlbumLbl: UILabel!
    @IBOutlet weak var mArtistLbl: UILabel!
    @IBOutlet weak var mTitleLbl: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print("Song to Play : \(song?.url ?? "")")
        createPlayerUI()
    }
    
    func createPlayerUI() {
         
        self.mAlbumLbl.text = song?.album
        self.mArtistLbl.text = song?.artist
        self.mTitleLbl.text = song?.title
    }
    
    
    //Music Control
    @IBAction func playMusicBtn(_ sender: Any) {
        print("Play Music")
        
    }
    @IBAction func pauseMusicBtn(_ sender: Any) {
        print("Pause Music")

    }
    @IBAction func stopMusicBtn(_ sender: Any) {
        print("Stop Music")
    }
    
    
}
