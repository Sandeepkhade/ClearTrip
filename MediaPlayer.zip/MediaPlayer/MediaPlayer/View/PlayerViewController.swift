//
//  PlayerViewController.swift
//  MediaPlayer
//
//  Created by Sandeep Khade on 28/10/23.
//

import UIKit
import AVFoundation

class PlayerViewController: UIViewController {

    @IBOutlet weak var mAlbumLbl: UILabel!
    @IBOutlet weak var mArtistLbl: UILabel!
    @IBOutlet weak var mTitleLbl: UILabel!
    
    var song : MySongs?
    var playerViewModel = PlayerViewModel()
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        playerViewModel.initAVPlayer(forURL: song?.url ?? "")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        createPlayerUI()
    }
    
    func createPlayerUI() {
         
        self.title = "ClearTrip Playing"
        self.mAlbumLbl.text = song?.album
        self.mArtistLbl.text = song?.artist
        self.mTitleLbl.text = song?.title
    }
    
    //Music Control
    @IBAction func playMusicBtn(_ sender: Any) {
       
        playerViewModel.playSong()
    }
    @IBAction func pauseMusicBtn(_ sender: Any) {
        
        playerViewModel.pauseSong()
    }
    @IBAction func stopMusicBtn(_ sender: Any) {

        playerViewModel.stopSong()
    }
}
