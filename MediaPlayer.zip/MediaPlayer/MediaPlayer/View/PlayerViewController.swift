//
//  PlayerViewController.swift
//  MediaPlayer
//
//  Created by Devarshi on 28/10/23.
//

import UIKit
import AVFoundation

class PlayerViewController: UIViewController {

    var song : MySongs?
    @IBOutlet weak var mAlbumLbl: UILabel!
    @IBOutlet weak var mArtistLbl: UILabel!
    @IBOutlet weak var mTitleLbl: UILabel!
    
    var audioPlayer: AVAudioPlayer?
    var avPlayer: AVPlayer?

    override func viewDidLoad() {
        super.viewDidLoad()
        print("Song to Play : \(song?.url ?? "")")
        createPlayerUI()

    }
    
    func createPlayerUI() {
         
        self.mAlbumLbl.text = song?.album
        self.mArtistLbl.text = song?.artist
        self.mTitleLbl.text = song?.title
    }
    
    func playMusic(url: URL?) {
        let avPlayerItem:AVPlayerItem = AVPlayerItem(url:url!)
        do {
            
            avPlayer = AVPlayer(playerItem: avPlayerItem)
            avPlayer?.play()
        } catch {
            print("Error While Preparing")
        }
    }
    //Music Control
    @IBAction func playMusicBtn(_ sender: Any) {
        print("Play Music")
        let stringURL = song?.url ?? ""
        var url = URL(string:stringURL)
        playMusic(url: url)
        
    }
    @IBAction func pauseMusicBtn(_ sender: Any) {
        print("Pause Music")
        audioPlayer?.pause()

    }
    @IBAction func stopMusicBtn(_ sender: Any) {
        print("Stop Music")
        audioPlayer?.stop()

    }
    
    
}
