//
//  SongsListViewController.swift
//  MediaPlayer
//
//  Created by Sandeep Khade on 28/10/23.
//

import UIKit

class SongsListViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, SongsDelegate {
   
    @IBOutlet weak var songsTableView: UITableView!
    var mySongs = [MySongs] ()
    var songViewModel = SongsViewModel()
    
    override func viewWillAppear(_ animated: Bool) {
        songViewModel.delegate = self
        songViewModel.getSongToDisplay()
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        initialiseUI()
    }

    func initialiseUI(){
        
        self.title = "ClearTrip Songs"
        self.songsTableView.delegate = self
        self.songsTableView.dataSource = self
    }
    
    func getDownloadedSongs(songs: [MySongs]) {
        self.mySongs = songs
        self.songsTableView.reloadData()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return mySongs.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        let songsCell = UITableViewCell(style: .subtitle, reuseIdentifier: "mySongsTableViewCell")
        let song = mySongs[indexPath.row]
        songsCell.textLabel?.text = "Title : \(song.title), Album : \(song.album)"
        return songsCell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    
        performSegue(withIdentifier: "PlayerViewController", sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let destination = segue.destination as? PlayerViewController {
            destination.song = mySongs[songsTableView.indexPathForSelectedRow!.row]
        }
    }
}
