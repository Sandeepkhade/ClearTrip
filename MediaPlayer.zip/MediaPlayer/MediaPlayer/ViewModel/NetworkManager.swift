//
//  NetworkManager.swift
//  MediaPlayer
//
//  Created by Devarshi on 28/10/23.
//

import Foundation


class NetworkManager {
    
//    static let sharedInstance = NetworkManager()
//    private init() {
//    }
    func fetchSongsData(comletion: @escaping([MySongs]) -> ()) {
        
        let urlFromString = URL(string: "https://www.jsonkeeper.com/b/C47J")
        
        URLSession.shared.request(url: urlFromString, expecting: [MySongs].self) { result in
            
            switch result {
            case .success(let songs):
                DispatchQueue.main.async {
                    comletion(songs)
                }
            case .failure(let error):
                print(error)
            }
        }
    }
}

extension URLSession {
    
    func request <T: Codable>(url: URL?,expecting: T.Type, completion: @escaping(Result<T, Error>) -> Void) {
        
        guard let url = url else {
            completion(.failure(CustomError.invalidURL))
            return
        }
        let task = self.dataTask(with: url) { data, _, error in
            
            guard let data else {
                if let error = error {
                    completion(.failure(error))
                } else {
                    completion(.failure(CustomError.invalidData))
                }
                return
            }
            do {
                let result = try JSONDecoder().decode(expecting, from: data)
                completion(.success(result))
                
            } catch {
                completion(.failure(error))
                
            }
        }
        task.resume()
    }
}


enum CustomError: Error {
    case invalidURL
    case invalidData
}
