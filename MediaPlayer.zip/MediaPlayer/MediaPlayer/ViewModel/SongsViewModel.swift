//
//  SongsViewModel.swift
//  MediaPlayer
//
//  Created by Sandeep Khade on 28/10/23.
//

import Foundation


protocol SongsDelegate {
    
    func getDownloadedSongs(songs:[MySongs])
}

class SongsViewModel {
    
    var delegate : SongsDelegate?
    
    func getSongToDisplay() {
        let networkManager = NetworkManager()
        networkManager.fetchSongsData { [self] songs in
            self.delegate?.getDownloadedSongs(songs: songs)
        }
    }
}
