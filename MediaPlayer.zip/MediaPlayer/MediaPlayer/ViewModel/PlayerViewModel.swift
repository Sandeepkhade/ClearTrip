//
//  PlayerViewModel.swift
//  MediaPlayer
//
//  Created by Sandeep Khade on 28/10/23.
//

import Foundation
import AVFoundation

class PlayerViewModel {
    
    var audioPlayer: AVAudioPlayer?
    var avPlayer:AVPlayer?
    var playerItem:AVPlayerItem?
    
    func initAVPlayer(forURL: String) {
        
        let url = URL(string:forURL.trimmingCharacters(in: .whitespaces))
        playerItem = AVPlayerItem(url:url!)
        avPlayer = AVPlayer(playerItem: playerItem)
    }
    func playSong() {
        avPlayer!.play()
    }
    
    func pauseSong() {
        avPlayer!.pause()
    }
    
    func stopSong() {
        avPlayer!.pause()
    }
}
