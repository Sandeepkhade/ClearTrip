//
//  MySongs.swift
//  MediaPlayer
//
//  Created by Devarshi on 28/10/23.
//

import Foundation

struct MySongs: Codable {
    
    let title : String
    let artist : String
    let album : String
    let url : String
}
